+++
title = "About"
date = "2017-06-24T18:57:12+07:00"
menu = "main"
+++
It's a minimalist and responsive theme for Hugo Static Site Generator. It's
name taken from Indonesian Language for *Sweet*.
