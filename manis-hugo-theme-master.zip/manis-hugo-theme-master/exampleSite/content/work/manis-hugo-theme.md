+++
title = "Manis Hugo Theme"
date = "2017-06-24T20:47:35+07:00"
tags = [
  "hugo"
]
draft = false
workURL = "https://github.com/yursan9/manis-hugo-theme"
+++
It's a minimalist and responsive theme for Hugo Static Site Generator. It's
name taken from Indonesian Language for *Sweet*.

![Manis' Homepage view](https://raw.githubusercontent.com/yursan9/manis-hugo-theme/master/images/tn.png)

## Features

Like I said, it's really minimal. Its doesn't even have grid or anything nice like that.

- Configurable color!
- Code Highlighting (HighlightJS).
- Responsive.
- Social Icon Links.
- No Grid no worry.
- Translatable.

![Manis' Colorful scheme](https://raw.githubusercontent.com/yursan9/manis-hugo-theme/master/images/blue-red.png)
